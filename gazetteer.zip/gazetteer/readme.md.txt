//TODO



5. As per the geonames example task, you must access all APIs via AJAX/PHP calls. This will obviate the fact that some of them are from non-secure URL. 
6. GitHub hosting is not appropriate for this application as it does not support server side operations.
7. There is no requirement for a search bar. Instead you are asked to produce a select pre-populated with country code as values and text as names. 
8. It’s best to place a event listener on the change event to provide a more fluent user experience.
9. I recommend the use of the Bootstrap library because it will give you the ability to optionally overlay modals containing attractively formatted tables of data. 
10. These can be invoked from Leaflet Easy Buttons.
11. ensure that the map fits neatly into the available space on scree aligning with right and bottom margins and that there are no view port scroll bars.




// DONE 

1. define one map and then change it’s state to focus on different locations. 
2. HTML, CSS and JS are in different files. 
3. Do not use CDNs and make sure that all stylesheets and JS libraries exist in folders in the project. 
4. CSS must be declared in the header and JS directly before the end body tag.




PHP AJAX Request

<!DOCTYPE html>
<html>
<head>
<script>
function showHint(str) {
  if (str.length == 0) {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    }
    xmlhttp.open("GET", "gethint.php?q="+str, true);
    xmlhttp.send();
  }
}
</script>
</head>
<body>

<p><b>Start typing a name in the input field below:</b></p>
<form action="">
  <label for="fname">First name:</label>
  <input type="text" id="fname" name="fname" onkeyup="showHint(this.value)">
</form>
<p>Suggestions: <span id="txtHint"></span></p>

</body>
</html>